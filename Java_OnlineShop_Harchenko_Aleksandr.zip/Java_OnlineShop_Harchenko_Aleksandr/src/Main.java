import java.util.*;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static List<Category> categories = new ArrayList<>();
    private static List<Client> clients = new ArrayList<>();
    private static List<Product> allProducts = new ArrayList<>();

    public static void main(String[] args) {
        initTestData();

        while (true) {

            System.out.println(" ГЛАВНОЕ МЕНЮ ");
            System.out.println(" 1. Работа с категориями ");
            System.out.println(" 2. Работа с товарами ");
            System.out.println(" 3. Работа с клиентами ");
            System.out.println(" 4. Сравнить товары ");
            System.out.println(" 5. Показать все категории ");
            System.out.println(" 0. Выход ");


            System.out.print("Выберите пункт: ");
            int choice = scanner.nextInt();
            scanner.nextLine();

            if (choice == 0) {
                System.out.println("До свидания!");
                break;
            }

            switch (choice) {
                case 1:
                    categoriesMenu();
                    break;
                case 2:
                    productsMenu();
                    break;
                case 3:
                    clientsMenu();
                    break;
                case 4:
                    compareProducts();
                    break;
                case 5:
                    showAllCategories();
                    break;
                default:
                    System.out.println("Неверный выбор!");
            }
        }
    }


    private static void categoriesMenu() {
        System.out.println("\n--- КАТЕГОРИИ ---");
        System.out.println("1. Добавить категорию");
        System.out.println("2. Сортировать категории");
        System.out.println("3. Найти категорию по ID");
        System.out.println("0. Назад");

        System.out.print("Выбор: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                addCategory();
                break;
            case 2:
                sortCategories();
                break;
            case 3:
                findCategoryById();
                break;
        }
    }

    private static void addCategory() {
        System.out.print("Введите название категории: ");
        String title = scanner.nextLine();
        System.out.print("Введите описание: ");
        String desc = scanner.nextLine();

        Category cat = new Category(title, desc);
        categories.add(cat);
        System.out.println("Категория добавлена! ID: " + cat.getId());
    }

    private static void sortCategories() {
        if (categories.isEmpty()) {
            System.out.println("Нет категорий для сортировки");
            return;
        }

        System.out.println("\nСортировать по:");
        System.out.println("1. По названию (А-Я)");
        System.out.println("2. По названию (Я-А)");
        System.out.println("3. По ID (возрастание)");
        System.out.println("4. По ID (убывание)");

        System.out.print("Выбор: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        List<Category> sorted = new ArrayList<>(categories);

        switch (choice) {
            case 1:
                sorted.sort(CategoryComparator.sortByTitleAscending());
                break;
            case 2:
                sorted.sort(CategoryComparator.sortByTitleDescending());
                break;
            case 3:
                sorted.sort(CategoryComparator.sortByIdAscending());
                break;
            case 4:
                sorted.sort(CategoryComparator.sortByIdDescending());
                break;
            default:
                return;
        }

        System.out.println("\n=== ОТСОРТИРОВАННЫЕ КАТЕГОРИИ ===");
        for (Category cat : sorted) {
            System.out.println("ID: " + cat.getId() + " | " + cat.getTitle());
        }
    }

    private static void findCategoryById() {
        System.out.print("Введите ID категории: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        for (Category cat : categories) {
            if (cat.getId() == id) {
                System.out.println("Найдено: " + cat.getTitle() + " - " + cat.getDescripton());
                return;
            }
        }
        System.out.println("Категория не найдена");
    }

    private static void showAllCategories() {
        if (categories.isEmpty()) {
            System.out.println("Нет категорий");
            return;
        }

        System.out.println("\n=== ВСЕ КАТЕГОРИИ ===");
        for (Category cat : categories) {
            System.out.println("ID: " + cat.getId() + " | " + cat.getTitle());
            System.out.println("   Описание: " + cat.getDescripton());
            System.out.println("   Товаров: " + cat.getProductsList().size());
            System.out.println();
        }
    }

    // ==================== МЕНЮ ТОВАРОВ ====================
    private static void productsMenu() {
        System.out.println("\n--- ТОВАРЫ ---");
        System.out.println("1. Добавить товар в категорию");
        System.out.println("2. Показать товары в категории");
        System.out.println("3. Сортировать товары в категории");
        System.out.println("0. Назад");

        System.out.print("Выбор: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                addProduct();
                break;
            case 2:
                showProductsInCategory();
                break;
            case 3:
                sortProductsInCategory();
                break;
        }
    }

    private static void addProduct() {
        if (categories.isEmpty()) {
            System.out.println("Сначала создайте категорию");
            return;
        }

        System.out.println("\nВыберите категорию:");
        for (int i = 0; i < categories.size(); i++) {
            System.out.println((i + 1) + ". " + categories.get(i).getTitle());
        }

        System.out.print("Номер категории: ");
        int catIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        if (catIndex < 0 || catIndex >= categories.size()) {
            System.out.println("Неверный выбор");
            return;
        }

        System.out.print("Название товара: ");
        String name = scanner.nextLine();
        System.out.print("Цена: ");
        double price = scanner.nextDouble();
        scanner.nextLine();
        System.out.print("Тип товара: ");
        String type = scanner.nextLine();

        // Создаём анонимный класс товара
        Product product = new Product(name, price, type, false) {
            @Override
            public void showInfo() {
                System.out.println(getType() + ": " + getName() + " | Цена: " + getPrice());
            }
        };

        categories.get(catIndex).addProduct(product);
        allProducts.add(product);
        System.out.println("Товар добавлен!");
    }

    private static void showProductsInCategory() {
        if (categories.isEmpty()) {
            System.out.println("Нет категорий");
            return;
        }

        System.out.println("\nВыберите категорию:");
        for (int i = 0; i < categories.size(); i++) {
            System.out.println((i + 1) + ". " + categories.get(i).getTitle());
        }

        System.out.print("Номер категории: ");
        int catIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        if (catIndex < 0 || catIndex >= categories.size()) {
            System.out.println("Неверный выбор");
            return;
        }

        categories.get(catIndex).showAllProducts();
    }

    private static void sortProductsInCategory() {
        if (categories.isEmpty()) {
            System.out.println("Нет категорий");
            return;
        }

        System.out.println("\nВыберите категорию:");
        for (int i = 0; i < categories.size(); i++) {
            System.out.println((i + 1) + ". " + categories.get(i).getTitle());
        }

        System.out.print("Номер категории: ");
        int catIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        if (catIndex < 0 || catIndex >= categories.size()) {
            System.out.println("Неверный выбор");
            return;
        }

        Category cat = categories.get(catIndex);
        if (cat.getProductsList().isEmpty()) {
            System.out.println("В этой категории нет товаров");
            return;
        }

        System.out.println("\nСортировать по:");
        System.out.println("1. По названию (А-Я)");
        System.out.println("2. По названию (Я-А)");
        System.out.println("3. По цене (возрастание)");
        System.out.println("4. По цене (убывание)");

        System.out.print("Выбор: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        List<Product> products = new ArrayList<>(cat.getProductsList());

        switch (choice) {
            case 1:
                products.sort(ProductComparator.sortByNameAscending());
                break;
            case 2:
                products.sort(ProductComparator.sortByNameDescending());
                break;
            case 3:
                products.sort(ProductComparator.sortByPriceAscending());
                break;
            case 4:
                products.sort(ProductComparator.sortByPriceDescending());
                break;
            default:
                return;
        }

        System.out.println("\n=== ОТСОРТИРОВАННЫЕ ТОВАРЫ ===");
        for (Product p : products) {
            System.out.println(p.getName() + " | " + p.getPrice() + " | " + p.getType());
        }
    }

    private static void clientsMenu() {
        System.out.println("\n--- КЛИЕНТЫ ---");
        System.out.println("1. Добавить клиента");
        System.out.println("2. Показать всех клиентов");
        System.out.println("3. Добавить товар в корзину");
        System.out.println("4. Показать корзину клиента");
        System.out.println("0. Назад");

        System.out.print("Выбор: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                addClient();
                break;
            case 2:
                showAllClients();
                break;
            case 3:
                addToCart();
                break;
            case 4:
                showCart();
                break;
        }
    }

    private static void addClient() {
        System.out.print("Имя клиента: ");
        String name = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Начальный баланс: ");
        double balance = scanner.nextDouble();
        scanner.nextLine();

        Client client = new Client(name, email, balance);
        clients.add(client);
        System.out.println("Клиент добавлен! ID: " + client.getId());
    }

    private static void showAllClients() {
        if (clients.isEmpty()) {
            System.out.println("Нет клиентов");
            return;
        }

        System.out.println("\n=== ВСЕ КЛИЕНТЫ ===");
        for (Client c : clients) {
            c.showInfo();
        }
    }

    private static void addToCart() {
        if (clients.isEmpty()) {
            System.out.println("Нет клиентов");
            return;
        }
        if (allProducts.isEmpty()) {
            System.out.println("Нет товаров");
            return;
        }

        System.out.println("\nВыберите клиента:");
        for (int i = 0; i < clients.size(); i++) {
            System.out.println((i + 1) + ". " + clients.get(i).getName());
        }
        System.out.print("Номер клиента: ");
        int clientIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        if (clientIndex < 0 || clientIndex >= clients.size()) {
            System.out.println("Неверный выбор");
            return;
        }

        System.out.println("\nДоступные товары:");
        for (int i = 0; i < allProducts.size(); i++) {
            System.out.println((i + 1) + ". " + allProducts.get(i).getName() + " | " + allProducts.get(i).getPrice());
        }
        System.out.print("Номер товара: ");
        int productIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        if (productIndex < 0 || productIndex >= allProducts.size()) {
            System.out.println("Неверный выбор");
            return;
        }

        clients.get(clientIndex).addToCart(allProducts.get(productIndex));
    }

    private static void showCart() {
        if (clients.isEmpty()) {
            System.out.println("Нет клиентов");
            return;
        }

        System.out.println("\nВыберите клиента:");
        for (int i = 0; i < clients.size(); i++) {
            System.out.println((i + 1) + ". " + clients.get(i).getName());
        }
        System.out.print("Номер клиента: ");
        int clientIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        if (clientIndex < 0 || clientIndex >= clients.size()) {
            System.out.println("Неверный выбор");
            return;
        }

        clients.get(clientIndex).showCart();
    }


    private static void compareProducts() {
        if (allProducts.size() < 2) {
            System.out.println("Нужно минимум 2 товара для сравнения");
            return;
        }

        System.out.println("\n=== СРАВНЕНИЕ ТОВАРОВ ===");
        System.out.println("Доступные товары:");
        for (int i = 0; i < allProducts.size(); i++) {
            System.out.println((i + 1) + ". " + allProducts.get(i).getName() + " | " + allProducts.get(i).getPrice() + " | " + allProducts.get(i).getType());
        }

        System.out.print("Выберите первый товар (номер): ");
        int idx1 = scanner.nextInt() - 1;
        System.out.print("Выберите второй товар (номер): ");
        int idx2 = scanner.nextInt() - 1;
        scanner.nextLine();

        if (idx1 < 0 || idx1 >= allProducts.size() || idx2 < 0 || idx2 >= allProducts.size()) {
            System.out.println("Неверный выбор");
            return;
        }

        Product p1 = allProducts.get(idx1);
        Product p2 = allProducts.get(idx2);

        System.out.println("\nПо какому критерию сравнить?");
        System.out.println("1. Название");
        System.out.println("2. Цена");
        System.out.println("3. Тип");

        System.out.print("Выбор: ");
        int crit = scanner.nextInt();
        scanner.nextLine();

        System.out.println("\n=== РЕЗУЛЬТАТ ===");
        System.out.println("Товар 1: " + p1.getName() + " | " + p1.getPrice());
        System.out.println("Товар 2: " + p2.getName() + " | " + p2.getPrice());

        switch (crit) {
            case 1:
                int nameCompare = p1.getName().compareToIgnoreCase(p2.getName());
                if (nameCompare < 0) {
                    System.out.println("➜ По названию: \"" + p1.getName() + "\" < \"" + p2.getName() + "\"");
                } else if (nameCompare > 0) {
                    System.out.println("➜ По названию: \"" + p1.getName() + "\" > \"" + p2.getName() + "\"");
                } else {
                    System.out.println("➜ Названия одинаковые");
                }
                break;
            case 2:
                if (p1.getPrice() < p2.getPrice()) {
                    System.out.println("➜ По цене: " + p1.getName() + " дешевле");
                } else if (p1.getPrice() > p2.getPrice()) {
                    System.out.println("➜ По цене: " + p1.getName() + " дороже");
                } else {
                    System.out.println("➜ Цены одинаковые");
                }
                break;
            case 3:
                if (p1.getType().equalsIgnoreCase(p2.getType())) {
                    System.out.println("➜ Оба товара одного типа: " + p1.getType());
                } else {
                    System.out.println("➜ Типы разные: " + p1.getType() + " vs " + p2.getType());
                }
                break;
            default:
                System.out.println("Неверный критерий");
        }
    }


    private static void initTestData() {

        Category electronics = new Category("Электроника", "Техника и гаджеты");
        Category books = new Category("Книги", "Художественная литература");

        categories.add(electronics);
        categories.add(books);


        Product iphone = new Product("iPhone 15", 50000, "Смартфон", false) {
            @Override
            public void showInfo() {
                System.out.println(getType() + ": " + getName() + " | Цена: " + getPrice());
            }
        };

        Product macbook = new Product("MacBook Pro", 150000, "Ноутбук", false) {
            @Override
            public void showInfo() {
                System.out.println(getType() + ": " + getName() + " | Цена: " + getPrice());
            }
        };

        Product book = new Product("Идиот", 450, "Книга", false) {
            @Override
            public void showInfo() {
                System.out.println(getType() + ": " + getName() + " | Цена: " + getPrice());
            }
        };

        Product book2 = new Product("Преступление и наказание", 550, "Книга", false) {
            @Override
            public void showInfo() {
                System.out.println(getType() + ": " + getName() + " | Цена: " + getPrice());
            }
        };


        electronics.addProduct(iphone);
        electronics.addProduct(macbook);
        books.addProduct(book);
        books.addProduct(book2);


        allProducts.add(iphone);
        allProducts.add(macbook);
        allProducts.add(book);
        allProducts.add(book2);


        clients.add(new Client("Датошка", "dato@gmail.com", 100000));
        clients.add(new Client("Владислива", "vlad@gmail.com", 50000));


    }
}
