import java.util.ArrayList;
import java.util.List;

public class Client implements Finansible{
    private int id;
    private String name;
    private String email;
    private double balance;
    private List<Product> cart;
    private static int nextId = 1;

    public Client(String name, String email, double balance){
        this.id = nextId++;
        this.name = name;
        this.email = email;
        this.balance = balance;
        this.cart = new ArrayList<>();
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance){
        this.balance = balance;
    }
    public void addToCart(Product product){
        cart.add(product);
        System.out.println(name + "добавил(а) в корзину: " + product.getName());
    }
    public void showCart(){
        if(cart.isEmpty()){
            System.out.println("Корзина пуста");
            return;
        }
        System.out.println("\n=== Корзина " + name + "===");
        double total = 0;
        for(Product p: cart){
            System.out.println(" - " + p.getName() + "|" + p.getPrice());
            total += p.getPrice();
        }
        System.out.println("Итого" + total);
    }
    @Override
    public double checkBalance(){
        return balance;
    }
    @Override
    public boolean hasEnoughMoney(double amount){
        return balance >= amount;
    }
    @Override
    public String getFinalStatus(){
        return "Клиент" + name + "| Баланс: " + balance;
    }
    public void showInfo(){
        System.out.println("ID: " + id + " Имя: " + name + "Email" + email + "Баланс" + balance);
    }


}