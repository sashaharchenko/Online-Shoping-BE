import java.util.Comparator;

public class ProductComparator {

    public static Comparator<Product> sortByNameAscending() {
        return new Comparator<Product>() {
            @Override
            public int compare(Product p1, Product p2) {
                return p1.getName().compareToIgnoreCase(p2.getName());
            }
        };
    }

    public static Comparator<Product> sortByNameDescending() {
        return new Comparator<Product>() {
            @Override
            public int compare(Product p1, Product p2) {
                return p2.getName().compareToIgnoreCase(p1.getName());
            }
        };
    }

    public static Comparator<Product> sortByPriceAscending() {
        return new Comparator<Product>() {
            @Override
            public int compare(Product p1, Product p2) {
                return Double.compare(p1.getPrice(), p2.getPrice());
            }
        };
    }

    public static Comparator<Product> sortByPriceDescending() {
        return new Comparator<Product>() {
            @Override
            public int compare(Product p1, Product p2) {
                return Double.compare(p2.getPrice(), p1.getPrice());
            }
        };
    }

    public static Comparator<Product> sortByTypeAscending() {
        return new Comparator<Product>() {
            @Override
            public int compare(Product p1, Product p2) {
                return p1.getType().compareToIgnoreCase(p2.getType());
            }
        };
    }
}