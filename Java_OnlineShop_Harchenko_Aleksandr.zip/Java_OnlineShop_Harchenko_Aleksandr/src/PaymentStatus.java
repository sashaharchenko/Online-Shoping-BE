public enum PaymentStatus {
    NO_PAID("Не оплачен"),
    PARIALLY_PAID("Частично оплачен"),
    PAID("Оплачено"),
    REFUNDED("Возврат");

    private final String title;
    PaymentStatus(String title){
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
