interface Pable {
    double getFinalPrice();
    void pay(double amount);
    boolean isPay();

}
