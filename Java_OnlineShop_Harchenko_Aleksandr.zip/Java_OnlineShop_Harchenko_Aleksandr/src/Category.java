import java.util.ArrayList;
import java.util.List;

class Category implements Comparable<Category> {
    private String categoryName;
    private ArrayList<Product> products;
    protected int id;
    protected String title;
    protected String descripton;
    private static int nextId = 1;
    private static List<Category> categories = new ArrayList<>();
    private List<Category> subCategories;

    public Category(String categoryName) {
        this.categoryName = categoryName;
        this.products = new ArrayList<>();
        this.subCategories = new ArrayList<>();
        this.id = nextId++;
        this.title = categoryName;
        this.descripton = "";
    }

    public Category(String title, String description) {
        this.title = title;
        this.descripton = description;
        this.products = new ArrayList<>();
        this.subCategories = new ArrayList<>();
        this.id = nextId++;
        this.categoryName = title;
    }

    public void addProduct(Product product) {
        products.add(product);
        System.out.println("Товар: \"" + product.getName() + "\" добавлен в категорию: " + categoryName);
    }

    public void showAllProducts() {
        System.out.println("\n--- " + categoryName + " ---");
        if (products.isEmpty()) {
            System.out.println("Нет товаров");
        } else {
            for (Product p : products) {
                p.showInfo();
            }
        }
        System.out.println("Всего товаров: " + products.size());
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescripton() {
        return descripton;
    }

    public void setTitle(String title) {
        this.title = title;
        this.categoryName = title;
    }

    public void setDescripton(String descripton) {
        this.descripton = descripton;
    }

    public static void addCategory(Category category) {
        categories.add(category);
        System.out.println("Категория добавлена: " + category.getTitle());
    }

    public static void showCategories() {
        if (categories.isEmpty()) {
            System.out.println("Нет категорий");
            return;
        }
        System.out.println("\n=== Список категорий ===");
        for (Category cat : categories) {
            System.out.println("ID: " + cat.getId() + " | " + cat.getTitle());
        }
    }

    @Override
    public int compareTo(Category other) {
        return this.title.compareToIgnoreCase(other.title);
    }

    public ArrayList<Product> getProductsList() {
        return products;
    }

    public List<Category> getSubCategories() {
        return subCategories;
    }

    public void addSubCategory(Category category) {
        this.subCategories.add(category);
        categories.add(category);
    }

    public int getSubCategoryCount() {
        return subCategories.size();
    }

    public void showFullHierarchy(int level) {
        StringBuilder indent = new StringBuilder();
        for (int i = 0; i < level; i++) {
            indent.append("  ");
        }
        System.out.println(indent + "📁 " + title);
        for (Product p : products) {
            System.out.println(indent + " [Товар] " + p.getName() + " | Цена: " + p.getPrice());
        }
        for (Category subCat : subCategories) {
            subCat.showFullHierarchy(level + 1);
        }
    }

    public static Category findCategoryByIdStatic(int id) {
        for (Category cat : categories) {
            if (cat.getId() == id) {
                return cat;
            }
        }
        return null;
    }

    public static Category findCategoryByTitleStatic(String title) {
        for (Category cat : categories) {
            if (cat.getTitle().equalsIgnoreCase(title)) {
                return cat;
            }
        }
        return null;
    }

    public static List<Category> getCategories() {
        return categories;
    }
}