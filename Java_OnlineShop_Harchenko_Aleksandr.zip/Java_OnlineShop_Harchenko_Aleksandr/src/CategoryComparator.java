import java.util.Comparator;

public class CategoryComparator {

    public static Comparator<Category> sortByIdAscending() {
        return new Comparator<Category>() {
            @Override
            public int compare(Category c1, Category c2) {
                return Integer.compare(c1.getId(), c2.getId());
            }
        };
    }

    public static Comparator<Category> sortByIdDescending() {
        return new Comparator<Category>() {
            @Override
            public int compare(Category c1, Category c2) {
                return Integer.compare(c2.getId(), c1.getId());
            }
        };
    }

    public static Comparator<Category> sortByTitleAscending() {
        return new Comparator<Category>() {
            @Override
            public int compare(Category c1, Category c2) {
                return c1.getTitle().compareToIgnoreCase(c2.getTitle());
            }
        };
    }

    public static Comparator<Category> sortByTitleDescending() {
        return new Comparator<Category>() {
            @Override
            public int compare(Category c1, Category c2) {
                return c2.getTitle().compareToIgnoreCase(c1.getTitle());
            }
        };
    }
}