import java.util.Objects;

abstract class Product implements Pable {
    protected String name;
    protected double price;
    protected String type;
    protected boolean payStatus;

    public Product(String name, double price, String type, boolean payStatus) {
        this.name = name;
        this.price = price;
        this.type = type;
        this.payStatus = payStatus;
    }

    public abstract void showInfo();

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Product product = (Product) obj;
        return Double.compare(product.price, price) == 0 && name.equals(product.name);
    }


    @Override
    public int hashCode() {
        return Objects.hash(name, price);
    }

    public String toString() {
        return "Product{name='" + name + "', price=" + price + ", payStatus=" + payStatus + "}";
    }

    @Override
    public double getFinalPrice() {
        return price;
    }

    @Override
    public void pay(double amount) {
        if (amount >= price) {
            payStatus = true;
        }
    }

    @Override
    public boolean isPay() {
        return payStatus;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public String getType() {
        return type;
    }

    public boolean isPayStatus() {
        return payStatus;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setPayStatus(boolean payStatus) {
        this.payStatus = payStatus;
    }
}