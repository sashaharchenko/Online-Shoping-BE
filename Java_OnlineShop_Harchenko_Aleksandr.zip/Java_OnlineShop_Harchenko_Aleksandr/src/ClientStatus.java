public enum ClientStatus {
    NEW("Новый Клиент"),
    ACTIVE("Активный клиент"),
    VIP("Vip клиент"),
    Blocked("заблокирован");

    private final String title;

    ClientStatus(String title){
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}
