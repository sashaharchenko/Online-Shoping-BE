public class MobileDevice {
}
