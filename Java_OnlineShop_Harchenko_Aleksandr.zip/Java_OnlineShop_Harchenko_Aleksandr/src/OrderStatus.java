public enum OrderStatus {
    CREATED("Создан"),
    PROGRESSING("В обработке"),
    PAID("Оплачен"),
    SHIPPED("Отправлен"),
    COMPLETED("Завершен"),
    CANCELLED("Отменен");

    private final String title;

    OrderStatus(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }
}