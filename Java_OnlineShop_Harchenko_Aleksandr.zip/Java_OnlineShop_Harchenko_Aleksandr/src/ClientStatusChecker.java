@FunctionalInterface
public interface ClientStatusChecker {
    boolean check(Client client);
}
