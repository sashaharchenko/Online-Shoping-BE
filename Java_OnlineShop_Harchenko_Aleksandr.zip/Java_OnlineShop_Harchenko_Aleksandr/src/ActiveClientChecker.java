public class ActiveClientChecker implements ClientStatusChecker{
    @Override
    public boolean check(Client client){
        return client.getStatus()==ClientStatus.ACTIVE || client.getStatus()==clientStatus.VIP;
    }
}
